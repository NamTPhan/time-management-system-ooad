create view verkoopresultaat as
  select `bestellingen`.`artikel`.`code`              AS `code`,
         `bestellingen`.`artikel`.`omschrijving`      AS `omschrijving`,
         `bestellingen`.`artikel`.`artikelPrijs`      AS `artikelprijs`,
         count(`bestellingen`.`bestelregel`.`aantal`) AS `aantalVerkocht`,
         `bestellingen`.`artikel`.`voorraad`          AS `voorraad`
  from (`bestellingen`.`artikel` join `bestellingen`.`bestelregel` on ((`bestellingen`.`artikel`.`code` =
                                                                        `bestellingen`.`bestelregel`.`artikelCode`)));

