create function VolledigAdres(adres varchar(30), postcode varchar(30), stad varchar(30))
  returns varchar(45)
  BEGIN
 IF (adres IS Null or adres='') then
 RETURN CONCAT(postcode, ' ', postcode);
 ELSE
 RETURN CONCAT(adres, ' ', postcode, ' ', stad);
 END IF;
END;

