create procedure `OpschonenOudeGegevens(pDatum)`()
  BEGIN
 DELETE lidnr FROM lidnr
 WHERE pDatum IS NULL AND
 lidnr NOT IN (SELECT DISTINCT overtredingsdatum FROM pDatum) AND
 lidnr NOT IN (SELECT DISTINCT speeldatum FROM pDatum) AND
 lidnr NOT IN (SELECT DISTINCT einddatum FROM pDatum);
END;

